/*
 * File - ColumnDB.java
 *
 * Original Author - Vivian Roshan Adithan
 *
 * Description - 
 *		...
 */
package diskmgr;

public class ColumnDB extends DB {
  public ColumnDB() {
    super();
  }
}
