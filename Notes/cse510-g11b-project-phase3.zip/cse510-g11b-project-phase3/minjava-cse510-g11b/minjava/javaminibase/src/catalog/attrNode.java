//------------------------------------
// attrNode.java
//
// Ning Wang, April, 1998
//-------------------------------------

package catalog;

public class attrNode
 {
  public String attrName;
  public String attrValue;
 }; 

